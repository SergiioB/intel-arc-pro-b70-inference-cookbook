# B70 Inference Host — Agent Contract

Intel Arc Pro B70 32 GB | llama.cpp SYCL and vLLM XPU

This file is the concise mandatory operating contract. Detailed research conclusions, live inventory, campaign narratives, and historical benchmark numbers live in their typed authorities.

## 0. Compile before browsing

Authority: `docs/governance/agent-operating-system.md`.

1. Name one intent: `ops` | `bench` | `diagnose` | `research` | `publish` | `site`.
2. Load only that working set (max 12 files). JSON ledger/status before Markdown.
3. Ignore `*.sync-conflict-*`.
4. Run `python3 tools/situation.py compile --intent <intent> --goal "<one line>" [--family <model>]`. Follow JSON `working_set`. If `halt` is true (blocked bench with no named change), stop. A blocked bench proposal resumes only with `--changed-variable "<what is different>"` — that records the difference; it does not authorize execution or waive any gate.

Do not paste headline tok/s into this file. Numbers travel results → campaign → cookbook catalog → XeCores renderer.

| Question | Authority |
|---|---|
| How an agent should load context | `docs/governance/agent-operating-system.md` |
| What is worth researching next (hypothesis → probe → gate → stop rule) | `registry/research-program.json` (Markdown view: `research/PROGRAM.md`) |
| What ran and what it measured (outcome record, guards) | `registry/research-ledger.json` (Markdown view: `research/LEDGER.md`) |
| Current route and open gates | `registry/model-status.json` (Markdown view: `models/STATUS.md`) |
| Research coverage (notes/evidence no record links) | `docs/indexes/research-coverage.md` (`python3 tools/research.py coverage`) |
| Compiler implementation spec | `docs/plans/2026-09-01-agent-situation-compiler.md` |

## 1. Locate the host before acting

```bash
hostname
pwd -P
```

If the hostname is `sergio-desktop`, operate locally. **Do not SSH to `192.168.1.133` from the B70 itself**; self-SSH fails and is unnecessary.

When controlling the B70 from another board, use the documented remote path. Telegram/Radxa operations are separate and must be explicitly requested.

## 2. Canonical authorities

| Question | Authority |
|---|---|
| Current mounts, free space, artifacts, active profile | `docs/operations/current-host-state.md` |
| Storage, conversion, and VRAM safety | `docs/operations/storage-and-vram-safety.md` |
| Benchmark validity and publication | `docs/methods/benchmark-protocol.md` (normative) |
| **Publish a benchmark to XeCores (one-edit cookbook flow)** | `docs/governance/public-benchmark-publication.md`; skill `.agents/skills/publish-b70-benchmark-results/SKILL.md` |
| Architecture Triage & Bottleneck Playbook | `docs/methods/architecture-diagnostic-playbook.md`; contract summary §18 |
| Runtime telemetry and power semantics | `docs/methods/observability-standard.md` |
| Correctness and quality gates | `docs/methods/correctness-validation.md` |
| Weight/KV/draft quantization decisions | `docs/reference/quantization-decision-record.md` |
| KV cache policy | `docs/reference/kv-cache-reference.md` |
| Engine support | `docs/reference/engine-support-matrix.md`; living dossiers `engines/<engine>/README.md` |
| Xe2 ESIMD / Decode Launch Bounds (vLLM bottleneck) | `research/2026/xe2-esimd-launch-bounds-2026-08.md` |
| Qwen3.8-27B FP8 TP2 Speed Attack & Ceilings | `research/2026/qwen38-fp8-tp2-speed-attack-and-ceilings-20260829.md`; dossier `models/qwen/qwen3.8-27b/serving.md` |
| Qwen3.8-27B official DFlash2 route (adoption-first decision, gates, stop rules) | `research/2026/qwen38-dflash2-objective-campaign-20260830.md`; campaign record `campaigns/2026/qwen38-dflash2-objective/README.md` |
| **Draft-side INT4 for MTP speculation (the campaign's biggest measured lever)** | `research/2026/qwen38-draft-side-int4-upstream-20260921.md` (upstream contribution draft); evidence `results/2026/09/b70-improvement-probes-20260920/p4-champion-ab-*`; dossier `models/qwen/qwen3.8-27b/serving.md` |
| **What won / what the measurements killed / what is open (improvement campaign 2026-09-20/21)** | `docs/plans/2026-09-20-b70-improvement-roadmap/OUTCOMES.md` (wins, losses, deciders) + `LEVERS.md` (every lever with its verdict) |
| Megakernels, Persistent Fusion, and Xe2/XMX Policy | `research/2026/megakernel-xe2-xmx-architecture-guide-20260829.md`; roadmap `research/2026/megakernel-implementation-roadmap-20260829.md`; policy `decisions/adr-0009-xe2-megakernel-and-persistent-fusion-policy.md`; contract §17 |
| Dual-B70 PCIe topology, link widths, dual-stack placement | `research/2026/x570f-dual-b70-pcie-topology-20260830.md` (B450-F note superseded 2026-08-30) |
| Dual-card product choice (independent stacks vs TP2) | `decisions/adr-0008-dual-b70-independent-default.md`; recipe capture `research/2026/humble-b70-llm-dual-tp2-20260824.md` |
| llama.cpp HTTP → token pipeline (K216 IQ3 SYCL, buses, bottlenecks) | short: this file §16; full: `research/2026/dsv4-k216-request-to-output-pipeline-20260825.md` |
| Current model route and open gates | `models/<family>/<model-slug>/README.md` |
| Why a route was selected | `decisions/` |
| Exact raw measurement | registered campaign plus `results/` evidence |
| Repository layout | `README.md` (root map); `DOCUMENT-MAP.md` + `docs/indexes/` are generated by `tools/build-indexes.py` |
| Standing recipe invariants (always-on / always-try / closed) and breakthrough candidates | this file §20; full analysis `research/2026/b70-breakthrough-architect-20260928.md` |
| Dated evidence layout (2026-09-15 restructure) | research notes `research/2026/<topic>-<YYYYMMDD>.md`; campaign narratives `campaigns/2026/<slug>/`; raw evidence `results/2026/<MM>/<slug>-<date>/`; pre-restructure flat paths are superseded |
| Agent working set / accretion | `docs/governance/agent-operating-system.md` |
| **Video generation (MiniMax H3, Comfy, dual-B70 split)** | Sibling `../B70-VIDEO/AGENTS.md` — not this inference contract |

When an older script/report conflicts with the benchmark protocol, the protocol wins.

The vendored Intel `gpu-ai-skills` skillpack in `.agents/skills/` (upstream `intel/gpu-ai-skills`) is supplemental generic guidance; on any conflict, this contract and the typed authorities win. See `.agents/skills/INTEL-GPU-AI-SKILLS.md` for provenance and known conflicts.

## 3. Hardware and runtime invariants

- GPUs: two Intel Arc Pro B70 cards, `xe` driver, 32,656 MiB visible VRAM each (65,312 MiB combined):
  - GPU 0 — PCI `0000:0b:00.0`: `/dev/dri/card0` + `renderD128`, Level Zero device 0 (`ZE_AFFINITY_MASK=0`).
  - GPU 1 — PCI `0000:0f:00.0`: `/dev/dri/card1` + `renderD129`, Level Zero device 1 (`ZE_AFFINITY_MASK=1`).
  - Level Zero device order follows BDF sort order; confirm with `sycl-ls` before targeting a card.
  - hwmon `xe` nodes must be resolved dynamically (`/sys/class/hwmon/*/name` → PCI device). Observed 2026-08-24: hwmon4 = `0000:0b:00.0`, hwmon5 = `0000:0f:00.0`; hwmon indices are boot-dependent.
  - PCIe links (ASUS ROG STRIX X570-F GAMING, dual CPU-attached x8/x8 — board swapped from B450-F on 2026-08-27; all results from 2026-08-27T23:10Z onward are X570-F): GPU 0 = `00:03.1` (PCIEX16_1, x8), GPU 1 = `00:03.2` (PCIEX16_2, x8); both slots CPU-attached (Starship/Matisse GPP root ports). **Direct-peer P2P copy capability is VERIFIED locally (2026-09-25, RL-059):** bidirectional checksum-clean ~11–12 GB/s, ACCESS flag set, **ATOMICS absent** (copy-based synchronization only). Measured H2D ≈ 8.9 / 7.9 GB/s (probe-limited — treat as a floor, not link bandwidth; `lspci` LnkSta misreports 2.5GT/s x1 on these endpoints even while active). Placement guidance: `research/2026/x570f-dual-b70-pcie-topology-20260830.md`. Dual-card **default** remains one independent engine per GPU (`ZE_AFFINITY_MASK`); vLLM `--tensor-parallel-size 2` is a gated research path (collective-correctness gate + matched-control campaign before any adoption, ADR-0008), not a stock Docker launch.
- GPU 1 is power-managed on demand via `/usr/local/bin/b70-gpu1`:

```bash
b70-gpu1 status        # both cards: presence, driver, render node, hwmon, cap, VRAM, temp
b70-gpu1 off           # PCI-remove GPU 1; Level Zero then enumerates GPU 0 only
b70-gpu1 on [WATT]     # PCI rescan + xe rebind; restores 150 W cap unless WATT given (max 230)
```

  - `off` refuses if a display is attached to GPU 1, a process holds real VRAM on it, or inference processes are running; `--force` overrides. Never force during a live campaign.
  - This is a driver-level power-down (PCI remove, D3), not a physical power cut.
  - After a power cycle, DRM render minors and hwmon indices can renumber (observed: `renderD129` → `renderD130`). Re-discover these paths; the desktop dashboard re-discovers automatically.
  - `on` also pins runtime PM to `on` up the PCI chain — mandatory: with runtime-auto, GPU 1's link has silently dropped 30–60 s after resume (flapping incident 2026-08-24 on the previous B450-F board; the pin remains required on the X570-F — 2026-08-30 verification found `control=auto` on both cards after rebind).
  - One-click toggle: desktop shortcut `B70 GPU 1 Power` (`~/Desktop/B70-GPU1-Power.desktop` → `/usr/local/bin/b70-gpu1-toggle`) flips the state with a desktop notification; the dashboard shows GPU 1 as `POWERED OFF` while it is removed.
- CPU: Ryzen 7 5700X3D; use 8 CPU threads for the established llama.cpp path.
- Discover storage live before every download/conversion; remembered sizes are invalid.
- Activate oneAPI before llama.cpp SYCL work:

```bash
source /opt/intel/oneapi/setvars.sh --force >/dev/null 2>&1
```

- Do not use `xpu-smi` or i915 clock tooling as B70 control/telemetry authorities. Use verified `xe` hwmon, debugfs VRAM, and perf PMU where required.
- Stock power-cap maximum is 230 W. The "restore 150 W" default was **retired by the operator 2026-09-14**: caps are not uniform across cards and swap across reboots — read and record each card's observed `power1_cap` before a campaign and restore as found at cleanup.

## 4. Empty-GPU gate — mandatory

Before every model load:

```bash
pgrep -af 'llama-server|llama-bench|vllm|vllm-xpu'
docker ps --format '{{.ID}} {{.Image}} {{.Names}}'
sudo cat /sys/kernel/debug/dri/0000:0b:00.0/tile0/vram_mm
sudo cat /sys/kernel/debug/dri/0000:0f:00.0/tile0/vram_mm
```

Also discover the B70 hwmon nodes (one per card) and record `power1_cap` per card (the 150 W default is retired 2026-09-14 — caps vary per card and across reboots; restore as found at cleanup).

All gates must pass:

- no inference process;
- no inference container;
- approximately 31,000 MiB or more empty-card `visible_avail` on every card in use;
- one declared engine and one campaign harness only.

A controlled Cn campaign sends concurrent requests to one declared server. A second engine or unrelated GPU workload is contamination.

## 5. Post-load VRAM gates

| Free VRAM | Allowed work |
|---:|---|
| below 500 MiB | Abort; no request |
| 500–1,023 MiB | Isolated C1 capacity observation only |
| 1,024–2,047 MiB | Staged C1 research |
| at least 2,048 MiB | Preferred C1 performance work |
| at least 3,072 MiB | Target for mixed/concurrent serving |

A server launch is not a capacity result. Stage real prompt-plus-output requests.

Never full-offload a single GGUF above roughly 30 GB without an explicit partial-offload budget; this class can hard-crash the host.

## 6. llama.cpp mandatory serving defaults

Unless a campaign explicitly tests a different variable:

```text
-ngl 99
-ncmoe 0
-fa on
-ctk q8_0
-ctv q4_1
-t 8
--no-mmap
```

- `q8_0 K + q4_1 V` is the fleet-standard llama.cpp KV policy.
- **Never use q4_0 for K cache.** The recorded quality cliff is catastrophic.
- Model-weight Q4_0 is a separate representation and does not relax the KV rule.
- Always declare context with `-c`; choose it from the serving target and measured reserve.
- Vision requests require the exact projector and sufficient output tokens for reasoning models.

## 7. vLLM XPU discipline

- Pin a pullable image by immutable digest and record observed in-container vLLM/kernel versions.
- Verify exact architecture registration, checkpoint metadata, packing, quantization, and kernel dispatch.
- GPTQ-INT4/W4A16 is a best-proven practical B70 path for exact validated checkpoints; it is **not** a universal format guarantee — on Qwen3.8-27B the whole symmetric-int4 class is closed (ADR-0010); the primary route there is `exl3xpu` on its own isolated dockerd (`unix:///run/b70-exl3-docker.sock`, bridge `b70-exl3-br0`, data-root on a large mount — the ~32 GB image must never pull into the main dockerd's root disk; force overlay2 or an external containerd so pulls do not land in `/var/lib/containerd`). Engine taxonomy: `exl3xpu` is a separate engine from `vllm-xpu` — `engines/exl3xpu/README.md`.
- Keep target-weight, draft/MTP/DFlash, LM-head, activation, and KV precision as independent axes.
- Apply only patches anchored to the exact source generation. Record each as upstream, required, not applicable, rejected, or local-only.
- Local derived images are not public recipes.
- Prefix caching in vLLM V1 defaults on unless explicitly disabled; verify server logs and counters.
- Dual-card default is independent stacks (`ZE_AFFINITY_MASK`). Do not launch stock `--tensor-parallel-size 2` on this X570-F host; TP2 needs host-staged collectives and the per-worker affinity patch, occupies both cards, and is validated only through the registered campaign recipe (ADR-0008).

## 8. Benchmark workflow

For “benchmark this model,” use `.agentic/skills/benchmark-model/SKILL.md`.

**Charts (2026-09-15 standard):** every comparison chart MUST follow
`docs/methods/chart-standard.md` — generated from evidence JSONs by a
committed renderer (never hand-typed), fixed engine colors, log-x context
axis, line style encodes protocol (solid full / dashed probe / dotted
reference), sparse labels, legend panel below the plot, PROVISIONAL
banner, and a vision-QA PASS on the rendered PNG before anything ships.
After any campaign: renderer → charts → engine dossiers → cookbook pages
→ release, in that order — skipping steps is how stale numbers survive.
Engine taxonomy is explicit: OpenVINO GenAI, Cascadia, and OVMS are
separate engines (`engines/<engine>/README.md`) and are never merged in
tables or charts.

Default Lane 1 card:

- p2048/g1 cold input;
- p8192/g1 cold input;
- p512/g128 decode;
- p8192/g128 decode;
- one representative real workload;
- fresh n=5 final samples.

MTP/config screens use matched p512/g128 and p8192/g128 n=3, then a fresh n=5 finalist confirmation. Acceptance is diagnostic; choose the winner by the declared throughput/latency/capacity/quality objective.

### Measurement naming

- vLLM `actual endpoint input tokens / client TTFT` is **cold input rate**, not llama-bench pp or isolated prefill.
- Client post-first rate is request-side, not engine-native llama.cpp tg.
- C1 and Cn aggregate metrics never share an unlabeled field.
- For Cn, use successful generated tokens divided by the declared campaign interval; never sum per-request rates as wall aggregate.
- A short best sample is maximum observed, not representative or sustained.

### Sampling policy (2026-08-30)

- Published/representative decode numbers use the checkpoint's model-card recommended sampling (Qwen3.8: non-thinking temp 0.7, top_p 0.8, top_k 20, presence penalty 1.5; thinking temp 1.0, top_p 0.95, top_k 20; see `models/qwen/qwen3.8-27b/serving.md` Run 48).
- Greedy (temp 0) cells are diagnostic maxima: acceptance references and build comparisons only, always labeled "greedy synthetic" and never published as the representative number.
- Random-token synthetic prompts (e.g. `vllm bench serve --dataset-name random`) inflate speculative acceptance relative to natural text; every speculative number carries its prompt-content class.

### Single-client measurement gate (2026-08-30)

- A C1 campaign server is measured by exactly one client at a time. Platform submitters (`lmx`, the XeCores runner) run strictly serially, each bracketed by server prefix-cache and spec-decode counter snapshots. Concurrent clients queue against `--max-num-seqs 1`, inflate TTFT, and depress both numbers simultaneously (2026-08-30 lmx/runner overlap: 28.6 vs 50 tok/s on the identical server); affected runs are marked superseded and re-measured.

### HTTP cache guards

For every cold HTTP input cell:

1. Put at least 64 characters of unique entropy at the start while preserving exact total tokens.
2. Snapshot prefix-cache queries/hits before and after.
3. Require zero cache-hit delta.
4. Verify actual endpoint prompt tokens.
5. Investigate unexplained material acceleration across equal-length repetitions.

## 9. Warmup, cooldown, and progress

- Discard one same-shape warmup for every distinct shape/mode as required by the protocol.
- Cool to the declared verified GPU package threshold, normally at most 52–55 °C, between comparable tests.
- Run campaigns under a visible controlling process.
- Emit milestones before/after load, warmup, each cell, configuration change, retry, timeout, and cleanup.
- Stop when progress exceeds the declared timeout; do not leave an unobservable detached campaign.

## 10. Power and thermal claims

Discover the `xe` hwmon node dynamically; never hard-code `hwmon4` in new evidence.

Average card draw:

```text
(energy_end_uJ - energy_start_uJ) / elapsed_seconds / 1,000,000
```

Use monotonic time and align energy reads to the exact workload interval. Record raw energy, elapsed time, resolved path, configured cap, cadence, named temperatures, and coverage. A maximum 0.5–1.0 s delta is **peak interval-average W**, not instantaneous peak.

B70 `xe` hwmon energy counters: `energy1_input` = card domain, `energy2_input` = pkg domain (both µJ). Reading a counter resumes a runtime-suspended GPU; pin runtime PM before energy telemetry.

Configured cap is not measured draw. Campaign-wide telemetry with unmatched phase coverage cannot establish a mode-to-mode power difference.

## 11. Quantization and artifact safety

Treat architecture, checkpoint representation, engine/kernel support, quality, and performance as separate gates.

- Identify formats from config and tensors, not repository titles.
- Prefer a native compatible artifact.
- Distinguish reconstruction, repack, and requantization.
- Preserve source artifacts unchanged.
- Never write an output index through a source symlink.
- Record exclusions and mixed-precision tensors.
- Validate static coverage, numerical behavior, coherent load, deterministic replay, reference/parity, and task quality in increasing cost order.
- A successful conversion or load is not parity.
- Artifact presence is independent from recommendation and quality state.

## 12. Evidence, claims, and publication

Retain under one UTC result root:

- manifest and exact identities;
- prompts/hashes and actual tokens;
- all raw samples;
- server/harness logs;
- cache and MTP counter snapshots;
- synchronized monitor and VRAM state;
- failures/exclusions;
- formulas and statistics;
- cleanup state.

Use the mandatory `.agents/skills/b70-benchmark-claims-standard/SKILL.md` for any benchmark, comparison, public number, recommendation, portfolio/social content, or LocalMaxxing projection.

To actually publish to the public XeCores catalog, follow `.agents/skills/publish-b70-benchmark-results/SKILL.md` (governance: `docs/governance/public-benchmark-publication.md`).

Until the lane, evidence, and claims audit pass, label results:

> PROVISIONAL — NOT FOR PUBLIC HEADLINE

LocalMaxxing `APPROVED` means accepted/published self-report, not independent reproduction.

No commit, push, deployment, social post, portfolio update, leaderboard submission, or external publication is implied by benchmark completion. Obtain separate authorization.

## 13. Cleanup

On exit:

1. stop the exact campaign server/container;
2. restore each card's pre-campaign observed cap (the 150 W default is retired 2026-09-14 — caps vary per card and across reboots);
3. re-run process/container/VRAM gates;
4. retain cleanup evidence;
5. restart a production service only when authorized and its artifact is valid.

For user services in agent shells:

```bash
export XDG_RUNTIME_DIR=/run/user/$(id -u)
export DBUS_SESSION_BUS_ADDRESS=unix:path=${XDG_RUNTIME_DIR}/bus
```

See `docs/operations/incident-and-cleanup.md`.

## 14. Script policy

New benchmark scripts start in `scripts/tmp/`. Promotion to `scripts/` requires:

- a complete header explaining use, actions, output, safety, and example;
- one successful controlled run;
- protocol-compliant evidence output;
- isolation, cooldown, trap, cleanup, and restoration of the pre-campaign observed cap (the 150 W default is retired 2026-09-14);
- an entry in the canonical script decision matrix.

`~/inference/benchmark.py` is a development smoke tool only and is not citable.

## 15. Historical reference

The pre-migration comprehensive host notebook is preserved at:

`archive/docs/pre-migration-20260819/AGENTS.md`

It contains important historical findings but also volatile inventories and superseded claims. Use current typed authorities first, then follow registered evidence and decisions for history.

## 16. llama.cpp SYCL request-to-output (DeepSeek-V4 K216)

> **ARCHIVAL (scope change 2026-09-23):** DeepSeek-V4/K216 is retired and its artifacts were
> deleted. This section is a transferable MoE diagnostic record (host-sync and grouped-GEMM
> failure modes, placement lessons), not current route guidance. Its numbers and closures bind
> that artifact on that engine only. Current questions: `research/PROGRAM.md`.

Full walk, buses, and ranked levers: `research/2026/dsv4-k216-request-to-output-pipeline-20260825.md`. Sister notes: `research/2026/dsv4-k216-prefill-ubatch-20260825.md`, `research/2026/dsv4-k216-dspark-and-public-numbers-20260825.md`, `research/2026/dsv4-k216-buun-moe-cache-20260825.md`.

C1 HTTP on this host is: socket → JSON/chat template → tokenize → ubatch graph (`min(-b,-ub)`) → serial `-sm layer` GPU0 then host-staged copy then GPU1 → DSA/indexer attention (not spec decode) → routed MoE `MUL_MAT_ID` → sample → chunked socket. Localhost HTTP/tokenize/sample are not the wall.

**Decode wall (PROVISIONAL best 9.25 clean / 9.58 patched engine tok/s at L5 `-ncmoe 15 -ts 65,35`, re-measured 2026-09-21 on the re-downloaded artifact; 8.87 superseded):** IQ3_XXS is omitted from fused SYCL `MUL_MAT_ID` MMVQ **upstream at `1692f9e50`**, but the pinned tree `/home/sergio/llama.cpp` already carries uncommitted device-ID cases for IQ3_XXS/IQ3_S, so on this host the host-ID fallback applies only to the multi-token path. That fallback D2H-copies ~24 B of expert IDs and `stream->wait()`s per routed projection (~84 waits/token on L5 GPU-routed layers). **Measured 2026-09-21: the device-ID repair is worth +3.54 % end-to-end (ABBA, n=6/build) and its ≥10 % gate FAILED** — it is a SYCL-graph-capture prerequisite, not a speed lever (`results/2026/09/b70-improvement-probes-20260920/p1-k216-e2e-ab-20260921T081155Z/`; roadmap P1 = WITHDRAWN). The fused routed op itself runs **5.52× above its weight-read floor**, which is kernel efficiency rather than synchronization. `-ncmoe N` puts the first N layers’ **experts** on CPU (mmap + DDR4-2133). Dual split is capacity, not per-layer 2×. [CORRECTED 2026-09-29 — the earlier "no P2P" clause was wrong and contradicted §3/§18 of this file: peer P2P **copy** is VERIFIED (11.1–11.9 GB/s checksum-clean, RL-059) and only **atomics** are absent; measured H2D ≈ 8.9/7.9 GB/s is probe-limited, a floor not link bandwidth.]

**Prefill wall (PROVISIONAL; the config lever is EXHAUSTED — measured 2026-09-21; the as-built grouped-IQ3 kernel FAILED its ≥2× gate 2026-09-23: 1.39–1.41× SLOWER, measured — see `results/2026/09/b70-improvement-probes-20260920/kernel-iq3-e0a/RESULTS.md` and roadmap L9; the only remaining prefill path is an IQ3_XXS extension on upstream #29245):** host counting-sort grouping + IQ3→FP16 then oneMKL. Measured ubatch curve at p7000/g1, `-c 8448`: **512 → 101.20 pp, 1024 → 130.78 (1.292×), 2048 → 131.10 (+0.2 %, saturated), 4096 → `UR_RESULT_ERROR_OUT_OF_DEVICE_MEMORY`**. The whole ubatch win is the 1.292× at 1024; no further flag sweep will pay. **The only remaining prefill lever is a grouped-IQ3 kernel that does not materialize whole experts as FP16**: the routed op measures **28.87 ms/op (1.79 TFLOPS) at ub 512 against ~46 TFLOPS for a comparable dense GEMM on the same card (~25× gap)** and it is the entire prefill budget (86.6 ms/layer → 3.72 s of a 5.06 s ubatch). Kernel gate baseline: `results/2026/09/b70-improvement-probes-20260920/perf-k216-prefill-n512.txt` (≥2× isolated-op, then ≥15 % matched end-to-end).

Do not retry: `-ts 46,54`/`50,50` low ncmoe, `-sm row`, single GPU, GPU-resident Unsloth DSpark (256-expert `dflash`) on L3/L5, `ggml_sycl_supports_mmq()` flip, SYCL graphs on dual+`MUL_MAT_ID`, `--no-mmap`/`--mlock` on this ~83 GiB GGUF, q4_0 K, spiritbuun `-ot 'exps=CPU' --moe-cache on` on this SYCL build (CUDA-only cache; all-CPU experts without it is slower than L5). CPU-MoE DSpark accepted well and was slower (2.48 tg). Packed P15_65 loaded (GPU0 1897 / GPU1 1720 MiB free) then exited unmeasured; P15_60 SYCL1 OOM 2.21 GiB. **Added 2026-09-21:** ubatch beyond 1024 (saturated at 2048, OOM at 4096); the device-ID repair pursued as a *speed* target (measured, gate failed, withdrawn); prefill flag sweeps in general (the lever is the kernel, not a flag). **Added 2026-09-23:** the grouped-IQ3 from-scratch kernel (measured 1.39–1.41× SLOWER — the lever is a different scheduling structure, i.e. the #29245 extension, not a new tile design); IQ3 code reorder (#29107) as a K216 decode lever (measured +0.08 % — it is a dense-model effect; the routed MUL_MAT_ID path is not reordered); verify-pass LM-head INT4 (offline gate: top-1 agreement 72 %); MTP depth beyond 4 (zero-GPU economics: flat within ±1.4 %). **Added 2026-09-29:** SYCL graph capture for the multi-token `MUL_MAT_ID` path is **not unblocked** by #28476/`304665fe7` — that merge added IQ MMVQ dispatch only; the local tree still rejects `ids->ne[1] != 1` and the multi-token path keeps `memcpy`+`stream->wait()`. Do not cite #28476 as satisfying the graph prerequisite.

Architect range with fused IQ3 MMVQ and a **compatible 216-expert** GPU draft: ~9.6–18 tok/s. **30 tok/s C1 is not realistic on this SYCL IQ3 MoE path.** Label all of the above provisional; no public headline.

## 17. Megakernels, Persistent Fusion & Xe2/XMX Guidelines

Full reference manual: `docs/reference/megakernel-comprehensive-reference.md`; architecture guide: `research/2026/megakernel-xe2-xmx-architecture-guide-20260829.md`; roadmap: `research/2026/megakernel-implementation-roadmap-20260829.md`; policy: `decisions/adr-0009-xe2-megakernel-and-persistent-fusion-policy.md`.

### Core Rules for Kernel Optimization on B70:
1. **Decode ($M=1$) vs. Prefill Separation:** In single-token decode, standard multi-kernel execution wastes $500+\,\mu\text{s}$ per token in host-driver launch latency and repeatedly writes $8\text{ KB}$ activations to GDDR6. Persistent kernels maintain the residual stream in on-chip GRF (registers) / SLM across all layers.
2. **Single-Card Persistent Grid:** Target 32 work-groups (1 per Xe-core) on a single B70. Never attempt cross-card Tensor-Parallel (TP) megakernels across PCIe (x8 + x8, CPU-attached; P2P copy verified ~11–12 GB/s, ATOMICS absent — RL-059) (`ADR-0008`); use independent single-card persistent pipelines instead (`ZE_AFFINITY_MASK`).
3. **Native DPAS Formats Only:** Persistent megakernels and XMX fast-paths require native systolic formats: **INT4 (GPTQ/AWQ)**, **INT8**, or **FP16/BF16**. Non-native formats (IQ3, Q3_K) force scalar unpack loops on Vector Engines and destroy persistent performance. **Rate-class law (2026-09-15):** sub-8-bit operands do NOT add TOPS on Xe2 — every ≤8-bit int mix with an 8-bit operand ties INT8 (363 TOPS class vs 170 BF16); INT4 is a weight-bandwidth/capacity lever (decode win), never a compute multiplier; Battlemage has no native FP8 DPAS, so FP8-W8A16 runs in the BF16 half-rate class (`research/2026/xmx-dpas-rate-classes-20260915.md`).
4. **Sub-Group Specialization:** In Xe-core work-groups, dedicate 1–2 producer sub-groups to asynchronous 2D block prefetching (`esimd::block_load_2d`) from GDDR6 to SLM, and 6–7 consumer sub-groups to XMX `dpas` systolic compute.
5. **Host-Sync Elimination Gate:** Any MoE/GEMV optimization must verify zero intermediate host synchronizations (`stream->wait()` or D2H expert-ID copies). On-device router-to-GEMV dispatch is mandatory.
6. **vLLM Decode Kernel Bounds:** Before benchmarking vLLM on Xe2, ensure `vllm-xpu-kernels` is built with explicit sub-group size bounds (`[[intel::reqd_sub_group_size(16)]]`) and `VLLM_PAGED_DECODE_CONFIG` to prevent GRF register spills (`research/2026/xe2-esimd-launch-bounds-2026-08.md`).

## 18. Architecture-First Triage & Diagnostic Quick Reference

Authority: `docs/methods/architecture-diagnostic-playbook.md`.

Before modifying configs, writing kernels, or launching sweeps, determine the model class and hardware placement:

| Model Family / Setup | Dominant Bottleneck | Primary Lever & Action | Never Attempt (Anti-Pattern) |
|---|---|---|---|
| **Large Dense ($27\text{B}\text{–}70\text{B}$)**<br>e.g. `Qwen3.8-27B` | GDDR6 bandwidth — **measured at byte floor single-card (2026-09-25, RL-061…065)** | 1. Speculative decode MTP4 + the draft-side INT4 pair (adopted champion)<br>2. Dual-card copy-based collectives on the verified P2P path (gated research, ADR-0008)<br>3. Aggregate serving (B=32 knee) when throughput beats latency | Single-card kernel/host hunting on the champion decode (closed at floor); verify-head quantization (quality-failed); small-corpus MTP-head retraining (D11); host-flag tuning |
| **Pure MoE**<br>e.g. `DeepSeek-V4 K216`, `Ornith-1.5` | Host-Device Sync ($84+$ D2H waits & `stream->wait()`) | 1. Keep router `top_k_indices` on-device<br>2. Fused `mul_mat_id_fused_moe_sycl`<br>3. Level Zero graph capture (`research/2026/dsv4-k216-request-to-output-pipeline-20260825.md`) | `-sm row` (segfaults); CPU-MoE without cache (`spiritbuun -ot exps=CPU` is slower); sweeping low `-ncmoe` |
| **Hybrid SSM + MoE**<br>e.g. `Nemotron-3.5-30B` | MoE+GEMM dispatch (73% of device time; fusable Mamba2/SSD family only 8% — P2 WITHDRAWN 2026-09-21) | 1. Small-M/grouped-GEMM (P5 reassigned into P3)<br>2. On-device 128-expert MoE router<br>3. DFlash drafter (`models/nemotron/nemotron-3.5-lightning-30b-a3b/serving.md`) | Unfused Mamba2 layers on XPU; older Q4_0 GGUF routes |
| **Dual B70 (X570-F)**<br>P2P copy capability verified; **no atomics** (2026-09-25) | Inter-card CCL traffic (latency-bound copy-based collectives) | 1. Default to independent single-card engines (`ZE_AFFINITY_MASK`) (`ADR-0008`)<br>2. TP2 only behind the collective-correctness gate + worker affinity + `SYS_PTRACE` + a matched 1-card control | Stock Docker TP2 without affinity patches; remote-atomics-dependent collectives; expecting $2\times$ scaling; inter-card TP megakernels |

## 19. Reddit extraction (verified 2026-09-26)

Best working route on this host — no API key needed:

```bash
# Search posts (full fields: score, author, selftext, created_utc, ...)
curl -s 'https://arctic-shift.photon-reddit.com/api/posts/search?subreddit=AskReddit&after=2026-07-01&before=2026-07-02&sort=desc&limit=100'

# Search comments
curl -s 'https://arctic-shift.photon-reddit.com/api/comments/search?subreddit=AskReddit&body=climate&limit=100'

# Full comment tree of one thread (link_id = t3_<postid>)
curl -s 'https://arctic-shift.photon-reddit.com/api/comments/tree?link_id=t3_1ul2c96&limit=9999'
```

Rules learned the hard way:

- **Unauthenticated Reddit `.json` is dead here** — 403 even with a browser User-Agent. Do not build on it (the `reddit-connector-mcp` npm package depends on it, so it likely fails too).
- **Reddit `.rss` still returns 200** (`/r/<sub>/new/.rss`, `/r/<sub>/comments/<id>/.rss`) but is rate-limited to a few rapid calls (then 429) and delivered only the post, no comment bodies, in tests. Use for discovery only.
- **Arctic Shift lags a few days** for brand-new threads (recent IDs return an empty tree). For fresh/live threads use the official OAuth API with PRAW (free app at reddit.com/prefs/apps; read-only needs no username/password) — untested here, no credentials stored.
- **pushshift.io / pullpush.io**: 429 and restricted to approved moderators. Skip.
- Treat Arctic Shift as an archive: scores may be stale, missing results do not prove absence, no uptime guarantee. Space out requests; back off on 429.

## 20. Standing recipe structure (2026-09-29)

Full analysis, breakthrough candidates, and probe designs: `research/2026/b70-breakthrough-architect-20260928.md`. This section is normative.

### Always-on rules

1. **XPU graph capture is always on** for vLLM XPU serving. A number taken with capture off is diagnostic-only, never a champion input. Every new kernel/patch must be capture-safe by construction and evaluated **under graph replay** (eager profiler traces are blind to graph-replayed kernels).
2. **Locked spec stack (per route, named — corrected 2026-09-29 per adversarial review):** on vLLM-XPU GPTQ-family stacks — stock MTP weights, MTP4, greedy drafting, draft-side INT4 pair, fp8 KV, presence_penalty 1.5; on the adopted exl3xpu route — native MTP3, fp8 KV, the artifact's own mixed head/mtp precision (head_bits=6, mtp_bits=4). Depth, drafting mode, and precision are named variables with pre-declared gates, never tweaks.
3. **Exact-answer battery + spec-canary before any speed claim.** Coherence, replay, and PPL all pass a fluent wrong answer (the 30-defect lesson).
4. **Prefix-cache policy (rescoped 2026-09-29):** OFF on W4A16+speculative stacks until vLLM #53912 is fixed (corruption reproduced with MTP4, including zero-hit first requests). The exl3xpu route's measured 5.4× cache win stands — cache-ON is allowed there, with cache state declared per cell and zero-hit-delta + entropy guards on cold cells (§8). Cache×speculation interaction is a shared-risk axis: any new engine/patch/draft combination gets one cache-ON multi-turn corruption check before cache-ON becomes its default.
5. **Output preservation:** lossless by construction or proven byte-identical (greedy) / same-modal-class (sampled). No approximate verify, ever.
6. **Metric naming is a claims rule:** every rate names its counted quantity — engine tokens, client post-first tokens, or SSE chunks. Chunk-rate ≠ tok/s.
7. **α bookkeeping:** counter form, yield = 1+4α (+0.05 α = +6.25 %); per-position survivals are marginal, reported separately — the profile is content-dependent and bimodal, never a uniform decay.
8. Single-client C1 gate (§8); independent dual-card stacks (ADR-0008); quantization axes independent (target/draft/MTP/LM-head/activation/KV).
9. **Attribution honesty:** "at floor" must name the floor; active-kernel share is not wall share.

### Always-try first moves (before any kernel work, in order)

Graph capture on → draft-side quantization pair on whatever drafter exists (the proven lever class) → byte-budget/roofline arithmetic **first** (measurement adopts, arithmetic prices — never reverse) → exact-answer canary first, speed second → count the draft-bytes axis at k× re-reads → acceptance economics at +6.25 % per +0.05 α with the per-position survival profile → attribution before optimization (bucket shares vs named physical floors) → price the KV-growth term at campaign depth (≈32 KiB/token × ctx on qwen3_5 full-attn blocks) → **metric-audit the harness counter** (what does it actually count?) → placement arithmetic before accepting "one card" (hidden states are µs-class over the verified P2P copy path — price what the idle card could do).

### Closed classes

"Closed" binds the named artifact, engine, and configuration. It is not a ban on the
mechanism class for other routes — on the current EXL3 route the M=4 verify kernel program
is **open** (`research/PROGRAM.md` RQ-01…RQ-04). Re-entry only via a named changed variable recorded in `registry/research-program.json`: single-card champion decode kernel/host hunting; the W4A16/GPTQ symmetric-int4 class on Qwen3.8-27B (30-defect; kernel-vs-weights discriminator owed); the tested acceptance frontier (D11/D12/D14, foreign-corpus shortlist, verify-head INT4, depth > 4); TP2 on stock oneCCL; grouped-IQ3 from scratch; #29107; vllm-xpu-kernels 0.1.15; #56096/#53989; QuaRot→INT3; W4A8 prefill; Cascadia PP2 speed; DFlash2-on-GPTQ; host-prep cache; max-num-batched-tokens; stock `--tensor-parallel-size 2`. Full list with evidence: `research/2026/b70-breakthrough-architect-20260928.md` §A.3.


