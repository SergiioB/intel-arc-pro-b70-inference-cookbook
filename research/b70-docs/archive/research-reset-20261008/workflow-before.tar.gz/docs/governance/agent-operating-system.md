---
title: "B70 Agent Operating System"
status: living
type: governance
date: 2026-09-01
---

---
id: b70-gov-agent-operating-system
title: B70 Agent Operating System
document_type: governance
status: canonical
version: "1.0"
effective_date: 2026-09-01
last_reviewed: 2026-09-01
authority: docs/governance/authority-map.md
scope: How an agent compiles a working set, spends context, accretes results, and crosses the private/public boundary
---

# B70 Agent Operating System

This document is the MMU for the B70 constellation. Typed docs already exist. The failure mode is an agent loading the library instead of compiling a working set.

Do not paste numbers into this file.

## 0. Do this first

1. Name **one** intent: `ops` | `bench` | `diagnose` | `research` | `publish` | `site`.
2. Load **only** that intent's working set (tables below). Cap: **12 files**.
3. Read **JSON before Markdown** for ledger and model status.
4. Ignore `*.sync-conflict-*`. Those are not documents.
5. Run `python3 tools/situation.py compile --intent <intent> --goal "<one line>"` and follow its list. Tables in §3 are the fallback if the CLI is missing.

If the intent is `site` or `publish`, do not open private `results/` unless the publication skill names a specific evidence root.

## 1. What this system is

Three repos, one tower, one number pipeline.

| Layer | Repo | Role | Agent may copy numbers? |
|---|---|---|---|
| L0 Kernel | `B70-DOCS/AGENTS.md` | Invariants, gates, host locate | No |
| L1 Situation | `registry/research-program.json` + `registry/research-ledger.json` + `registry/model-status.json` + `docs/operations/current-host-state.md` | Ranked questions, outcome record, current routes, volatile host | No (link ids) |
| L2 Method | `docs/methods/benchmark-protocol.md` + methods | How to measure and claim | No |
| L3 Decision | `decisions/` | Why a route exists | Link ADR |
| L4 Route | `models/<family>/<slug>/` | Current serving synthesis | Link dossier |
| L5 Campaign | `campaigns/` | Human interpretation of one campaign | Link `campaign_id` |
| L6 Evidence | `results/<id>/` | Immutable raw observation | Never rewrite |
| L7 Public | cookbook `data/benchmarks.v1.json` → xmxlab renderer | Only public numeric authority | Yes, via catalog only |

Numbers travel **up** the tower: L6 → L5 → (gate) → L7. They never travel down into L0, HTML, or Hermes skills.

**Pre-commitment probe gate (L2 rule, applies to every layer):** before any campaign,
compilation, conversion chain, calibration, or image pull expected to exceed 30 minutes,
declare hypothesis, thresholds, smallest falsifying probe, resource scope, and deadline;
pass the probe before committing the hours. Normative text:
`docs/methods/benchmark-protocol.md` §1.9 "Pre-commitment probe gate".

```
intent → compile (≤12 paths, 1 skill) → act → close-out (ledger + status + registry)
```

## 2. Constellation and privacy

| Repo | Visibility | Agent job |
|---|---|---|
| `B70-DOCS` (`~/B70-DOCS` on `sergio-desktop`) | private lab | Measure, diagnose, decide. Never vendor into the site. |
| `intel-arc-pro-b70-inference-cookbook` | public | One-edit catalog + recipes. Commit-pinned evidence. |
| `xmxlab` (XeCores / xecores.com) | local git, public site | Render L7. QA. Deploy only on explicit ask. |

Rock 5B copy of B70-DOCS is **Syncthing receiveonly**. Edits land on `sergio-desktop:/home/sergio/B70-DOCS`. A file that exists only on the Rock is not in the authority tree.

xecores.com is the live hub. `intelmaxxing.com` / `intelarcmaxxing.com` plans are tombstones (`docs/plans/intelmaxxing-com-architecture-plan.md`, `docs/plans/intelarcmaxxing-hub-plan.md`).

## 3. Intent → working set (compiler contract)

Each row is the **maximum** first load. Do not add files until a named path in this set points there.

### `ops` — is the host usable?

1. `AGENTS.md` §§1–5, 13
2. `docs/operations/current-host-state.md`
3. `docs/operations/storage-and-vram-safety.md`
4. Live `hostname`, `df`, empty-GPU gate (do not trust remembered VRAM)

### `bench` — measure one declared cell

1. `registry/research-ledger.json` (grep `blocked_pattern` against the planned script)
2. `registry/model-status.json` (family row; treat `blocked` guards as scoped history and prior `validated` cells as optional replication — label any re-measure as replication)
3. `docs/methods/benchmark-protocol.md`
4. `AGENTS.md` §§4–10, 14
5. `.agentic/skills/benchmark-model/SKILL.md` (one skill; do not also dump `.agents/skills/*`)
6. Named model dossier `models/<family>/<slug>/README.md` if a family is named

Stop if ledger outcome is `blocked` and the hypothesis did not change.

### `diagnose` — why is this slow / wrong?

1. `docs/methods/architecture-diagnostic-playbook.md`
2. `AGENTS.md` §18 table
3. Matching ADR (`adr-0008` for dual-card, `adr-0009` for megakernel, else dossier)
4. Matching `blocked` ledger rows only

### `research` — new question

1. `registry/research-program.json` + `research/PROGRAM.md` (JSON first) — the ranked queue with probes, gates, stop rules
2. `registry/research-ledger.json` + `research/LEDGER.md` (JSON first) — what ran and what it measured
3. `registry/model-status.json` + `models/STATUS.md`
4. `DOCUMENT-MAP.md`
5. One existing research note if the question already has an `evidence` path
6. New work only via a declared campaign with a changed variable

### `publish` — public number or recipe

1. `docs/governance/public-benchmark-publication.md`
2. `.agents/skills/b70-benchmark-claims-standard/SKILL.md`
3. `.agents/skills/publish-b70-benchmark-results/SKILL.md`
4. cookbook `data/benchmarks.v1.json`
5. xmxlab `AGENTS.md` benchmark publication contract

Do not copy a private result into XeCores HTML.

### `site` — XeCores / xmxlab

1. `~/projects/xmxlab/AGENTS.md`
2. `~/projects/xmxlab/DESIGN-AGENT-SYSTEM.md`
3. cookbook pin in `data/cookbook-b70/PROVENANCE.md`
4. Named QA script from xmxlab `AGENTS.md`

Never index `B70-DOCS` into the site.

## 4. Resource economy

| Question | Pay | Do not pay |
|---|---|---|
| Is this path blocked? | ledger JSON | a new bench |
| Current route / open gate? | model-status JSON | SSH into the GPU |
| What is on the GPU now? | empty-GPU gate + host-state | memory |
| Public tok/s? | cookbook `benchmarks.v1.json` | B70-DOCS prose |
| Site copy / nav / chat? | xmxlab tree | invent numbers |
| Did we already write this? | `DOCUMENT-MAP.md` + indexes | new parallel page |

Hermes skills (`b70-inference-ops`, `intel-arc-b70-llm`, `xecores-site-ops`) are **procedures**. Measured truth lives in this repo. If a skill number conflicts with L6/L7, the repo wins and the skill is stale.

## 5. Accretion (close-out)

A task is not done when the GPU is idle. It is done when the tower is updated.

**Must, in order:**

1. Keep the UTC result root immutable (`results/<id>/`).
2. Append a ledger row to `registry/research-ledger.json` (never edit old rows except `superseded_by`); update `registry/research-program.json` when an open question moves, closes, or splits; regenerate views with `python3 tools/research.py render`.
3. Update `registry/model-status.json` if a route, TP2/PP2 flag, or open gate changed.
4. Register the campaign in `registry/campaigns.yaml` when a result root exists.
5. Run `python3 tools/research.py check` (registry integrity + generated-view parity).
6. Restore each card's pre-campaign observed cap and pass empty-GPU (if the host was used).

**If Sergio authorized publication:**

7. Follow `docs/governance/public-benchmark-publication.md` (one edit in cookbook JSON).
8. In xmxlab: `npm run sync:cookbook` before the next deploy. Do not hand-edit fallback JSON numbers.

**Never:**

- Paste tok/s into `AGENTS.md`, xmxlab `*.html`, or Hermes skills.
- Vendor B70-DOCS into xmxlab.
- Delete inconvenient samples.
- Leave a second engine running.

## 6. Skill trees (load one)

| Tree | Use |
|---|---|
| `.agentic/skills/benchmark-model/` | Default "benchmark this model" |
| `.agents/skills/b70-benchmark-claims-standard/` | Any public or comparative number |
| `.agents/skills/publish-b70-benchmark-results/` | Promotion to cookbook/XeCores |
| `.agents/skills/` Intel gpu-ai-skills pack | Generic XPU setup only; this contract wins on conflict |

Do not load both `.agentic` and the full Intel pack for one task.

## 7. Compiler output shape (when `tools/situation.py` lands)

Stdout + `docs/indexes/situation-latest.md`:

```text
intent: bench
goal: <one line>
blocked: [RL-ids that matched]
prior_evidence: [scoped RL history — never a replication exemption or an adopted route]
working_set:
  - role: kernel
    path: AGENTS.md
    sections: [4, 5, 8]
  - role: situation
    path: registry/research-ledger.json
  ...
skill: .agentic/skills/benchmark-model/SKILL.md
do_not:
  - remeasure validated cell <id>
  - stock TP2 (RL-008)
budget_files: 8
```

Hard fail if `working_set` > 12 or if intent is `site` and any path is under `results/`.

Spec: `docs/plans/2026-09-01-agent-situation-compiler.md`.

## 8. Pitfalls

1. **Reading AGENTS.md end-to-end every turn.** Kernel + one intent table. §16–18 are only for those diagnose/research questions.
2. **Treating Markdown LEDGER as executable.** JSON is executable. Markdown is the human view. If they drift, JSON wins until parity is restored.
3. **Trusting Hermes skill tok/s.** Skills drift. Catalog and `results/` do not.
4. **Editing B70-DOCS on the Rock.** receiveonly; next desktop sync can wipe it. Edit `/home/sergio/B70-DOCS`.
5. **Executing `xmxlab/STATUS.md`, `OVERNIGHT-BUILD-PROMPT.md`, or intelmaxxing plans.** Tombstones.
6. **New page instead of improving the existing surface.** XeCores rule: no parallel chat/results pages.
7. **Assuming xecores.com curl from Rock is the live site.** Movistar blocks Cloudflare; use `*.pages.dev`.

## Related authorities

- [Authority Map](authority-map.md)
- [Documentation Standard](documentation-standard.md)
- [Evidence Lifecycle](evidence-lifecycle.md)
- [Public Benchmark Publication](public-benchmark-publication.md)
- [DOCUMENT-MAP](../../DOCUMENT-MAP.md)
- xmxlab `DESIGN-AGENT-SYSTEM.md`
