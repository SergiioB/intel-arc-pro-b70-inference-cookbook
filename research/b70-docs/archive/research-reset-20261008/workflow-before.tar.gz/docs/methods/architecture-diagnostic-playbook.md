---
title: "B70 Architecture-First Diagnostic Playbook & Triage Guide"
status: living
type: method
date: 2026-09-15
---

---
id: b70-method-architecture-diagnostic-playbook
title: B70 Architecture-First Diagnostic Playbook & Triage Guide
document_type: method
status: canonical
version: "1.0"
effective_date: 2026-08-29
last_reviewed: 2026-08-29
authority: docs/methods/benchmark-protocol.md
scope: Deterministic architecture triage, bottleneck identification, and optimization routes for Intel Arc Pro B70
---

# B70 Architecture-First Diagnostic Playbook & Triage Guide

## 1. Purpose & Core Philosophy

We frequently encounter recurring performance ceilings across different LLM architectures on the Intel Arc Pro B70. To prevent repeating historical investigations and chasing false leads, **always classify the model by its architectural family and hardware placement before making changes or running benchmarks**.

```
                           ┌─────────────────────────────────────────────────────────┐
                           │      Architecture-First Triage Decision Tree            │
                           └────────────────────────────┬────────────────────────────┘
                                                        │
          ┌───────────────────────────┬─────────────────┴─────────────────┬───────────────────────────┐
          │                           │                                   │                           │
          ▼                           ▼                                   ▼                           ▼
┌───────────────────┐       ┌───────────────────┐       ┌───────────────────┐       ┌───────────────────┐
│ Large Dense (27B) │       │ Pure MoE (K216)   │       │ Hybrid SSM+MoE    │       │ Dual-Card (TP2)   │
│ Bandwidth-Bound   │       │ Host-Sync Bound   │       │ Dispatch-Bound    │       │ Topology-Bound    │
├───────────────────┤       ├───────────────────┤       ├───────────────────┤       ├───────────────────┤
│ • Do NOT tune     │       │ • Do NOT sweep    │       │ • Do NOT run      │       │ • Do NOT assume   │
│   flags or GEMVs  │       │   ncmoe / CPU-MoE │       │   unfused Mamba   │       │   P2P bandwidth   │
│ • Use Speculative │       │ • Fuse On-Device  │       │ • Fuse Mamba2 SSD │       │ • Default to      │
│   (MTP4/DFlash)   │       │   Router + GEMV   │       │   Block in GRF/SLM│       │   independent     │
│ • W8A16 Reroute   │       │ • Eliminate D2H   │       │ • On-Device MoE   │       │   stacks (ADR0008)│
└───────────────────┘       └───────────────────┘       └───────────────────┘       └───────────────────┘
```

---

## 2. Architectural Triage Matrix

| Model Family | Primary Example | Dominant Bottleneck | Correct Optimization Route | What NOT to Do (Anti-Patterns) | Authority Doc |
|---|---|---|---|---|---|
| **Large Dense ($27\text{B}\text{–}70\text{B}$)**<br>e.g. `Qwen3.8-27B` | GDDR6 bandwidth at current bytes/token | 1. Speculative decode on the current route (EXL3 4bpw + native MTP3; historically MTP4/DFlash on GPTQ/FP8)<br>2. Bytes economy: quantized draft/MTP pair, mixed head precision<br>3. Aggregate serving (C8–C16) when throughput beats latency | • Do NOT spend time tuning host flags for base decode.<br>• The "custom GEMV saves <1.5 %" closure binds the **removed** GPTQ route (RL-061…065) only — the EXL3 M=4 verify kernel program is **OPEN** (`research/PROGRAM.md` RQ-01…RQ-04). | [`research/2026/qwen38-fp8-tp2-speed-attack-and-ceilings-20260829.md`](../../research/2026/qwen38-fp8-tp2-speed-attack-and-ceilings-20260829.md) (FP8 era) · [`engines/exl3xpu/README.md`](../../engines/exl3xpu/README.md) (current) |
| **Pure MoE** | `DeepSeek-V4 REAP-K216`, `Ornith-1.5-35B` | **Host-Device Synchronization** ($84+$ blocking `stream->wait()` & D2H expert-ID transfers) | 1. Keep `top_k_indices` in GPU memory<br>2. Fused `mul_mat_id_fused_moe_sycl`<br>3. SYCL Command Graph Capture | • Do NOT run CPU-MoE without cache (`spiritbuun -ot exps=CPU` is slower).<br>• Do NOT test `-sm row` (causes segfaults).<br>• Do NOT sweep low `-ncmoe` flags. | [`research/2026/dsv4-k216-request-to-output-pipeline-20260825.md`](../../research/2026/dsv4-k216-request-to-output-pipeline-20260825.md) |
| **Hybrid SSM + MoE** | `Nemotron-3.5-Lightning-30B-A3B` | **Sequential Dispatch Lag** (736 Mamba2 kernel launches + MoE host waits) | 1. Fused Mamba2 SSD block kernel in GRF/SLM<br>2. On-device 128-expert MoE router<br>3. BF16 DFlash drafter | • Do NOT run unfused stock Mamba2 layers on XPU.<br>• Do NOT test older Q4_0 GGUF routes. | [`models/nemotron/nemotron-3.5-lightning-30b-a3b/serving.md`](../../models/nemotron/nemotron-3.5-lightning-30b-a3b/serving.md) |
| **Dual-Card Topologies** | Any model across 2x B70 | **Collective latency over a copy-only link** (PCIe Gen4 x8/x8, CPU-attached; P2P copy VERIFIED ~11–12 GB/s, ATOMICS absent — RL-059) | 1. **Default to independent single-card stacks** (`ZE_AFFINITY_MASK`)<br>2. If TP2, use host-staged collectives + per-worker CPU affinity | • Do NOT launch stock Docker TP2 without affinity patches.<br>• Do NOT attempt inter-card persistent megakernels (copy-only link, no atomics). | [`decisions/adr-0008-dual-b70-independent-default.md`](../../decisions/adr-0008-dual-b70-independent-default.md) |
| **Quantization & Math** | All models | **Non-Native DPAS Unpack Stalls** | 1. Use native DPAS formats: **INT4 (GPTQ/AWQ)**, **INT8**, **FP16/BF16** | • Do NOT use non-native quants (`IQ3_XXS`, `Q3_K`) in persistent XMX kernels. | [`decisions/adr-0009-xe2-megakernel-and-persistent-fusion-policy.md`](../../decisions/adr-0009-xe2-megakernel-and-persistent-fusion-policy.md) |

---

## 3. Step-by-Step Diagnostic Procedures

> Scenarios A–C are dated route-specific diagnostics (FP8 TP2, retired K216 MoE,
> Nemotron-era Mamba). Check `models/STATUS.md` for the current route and
> `research/PROGRAM.md` for what is actually open before following one.

### Scenario A: "Why is my Large Dense model (Qwen3.8-27B) slow on FP8?"
1. **Check the Theoretical Roofline:**
   - Model size in FP8 $\approx 28\text{ GB}$. Across 2 cards (TP2), each streams $14\text{ GB}$.
   - Memory bandwidth limit: $14\text{ GB} / 450\text{ GB/s} \approx 31.1\text{ ms}$ ($\approx 32.9\text{ tok/s}$ base).
2. **Check Speculative Decoding:**
   - Is MTP4 or DFlash enabled? If yes, what is the acceptance rate and step latency?
   - If acceptance is $>85\%$ but speed is $<50\text{ tok/s}$, step time is bloated ($\sim 76\text{ ms}$).
3. **Apply the Target Linear Attack:**
   - Check if dynamic activation quantization is running.
   - Apply `patch_fp8_w8a16.py` to route to `_xpu_C.fp8_gemm_w8a16` with `apply_input_quant = False`.
   - Pool oneDNN scratchpads in `onednn_ext.h`.
   - See full breakdown: [`research/2026/qwen38-fp8-tp2-speed-attack-and-ceilings-20260829.md`](../../research/2026/qwen38-fp8-tp2-speed-attack-and-ceilings-20260829.md).

---

### Scenario B: "Why is my MoE model (DeepSeek-V4, Ornith) stuck below 10 tok/s?"
1. **Check Host-Device Synchronization:**
   - In `ggml-sycl.cpp`, verify whether `GGML_OP_MUL_MAT_ID` is issuing a `stream->wait()` or D2H memory copy.
   - If yes, the GPU is idling while the CPU loops over individual expert GEMVs ($84+$ waits per token).
2. **Apply On-Device Dispatch:**
   - Keep router `top_k_indices` on-device in VRAM/SLM.
   - Implement on-device expert looping in SYCL/ESIMD.
   - Enable SYCL command graph capture (`zeCommandListCreate`).
   - See full breakdown: [`research/2026/dsv4-k216-request-to-output-pipeline-20260825.md`](../../research/2026/dsv4-k216-request-to-output-pipeline-20260825.md).

---

### Scenario C: "Why is my Hybrid SSM model (Nemotron-3.5) lagging?"
1. **Check Sequential Mamba Dispatch Overhead:**
   - 46 Mamba2 layers with 16 ops each $\implies 736$ launches per token.
2. **Apply Mamba2 Block Fusion:**
   - Fuse Conv1D + Selective Scan + SwiGLU + Grouped Norm into 1 work-group launch per layer.
   - Keep SSM states ($d_\text{state}=128$) in GRF registers.
   - See full breakdown: [`research/2026/megakernel-implementation-roadmap-20260829.md`](../../research/2026/megakernel-implementation-roadmap-20260829.md).

---

## 4. The Canonical "Do Not Retry" Graveyard

Before attempting any experimental configuration or optimization, verify that it is not listed in this graveyard of proven failures:

| Configuration / Approach | Context / Model | Result / Observed Failure | Reason It Fails on B70 |
|---|---|---|---|
| `-sm row` (Row split) | DeepSeek-V4 / Dual B70 | **Segmentation fault / Crash** | SYCL tensor row slicing unsupported on non-P2P PCIe bus. |
| `spiritbuun -ot 'exps=CPU' --moe-cache on` | DeepSeek-V4 K216 | **Slower than L5 baseline ($2.48\text{ tok/s}$)** | MoE cache is CUDA-only; all-CPU routing on SYCL hammers DDR4-2133. |
| `q4_0` for KV Cache | All models (llama.cpp) | **Catastrophic quality cliff** | K-cache quantization noise destroys attention precision (`ADR-0001`). Fleet rule: `q8_0 K + q4_1 V`. |
| Stock Docker vLLM TP2 | Dual B70 (X570-F) | **1:1 Host RAM bloat / oneCCL Deadlock** | Requires per-worker affinity patch + `SYS_PTRACE` (`ADR-0008`). |
| Non-DPAS quants (`IQ3_XXS`) in XMX persistent kernels | Xe2 / B70 | **Severe pipeline stall** | Lacks native DPAS instructions; forces scalar unpack loops on Vector Engines. |
| Configuration tuning alone for $75\text{ tok/s}$ on FP8 TP2 | Qwen3.8-27B FP8 | **Capped at $\sim 44\text{ tok/s}$** | Target verification linear GEMVs take $50\text{ ms}$; requires W8A16 / small-M kernel. |
| Inter-card TP Megakernel | Dual B70 (X570-F) | **Persistent grid stall** | Copy-only P2P (~11–12 GB/s, RL-059) with no atomics: barrier-synchronized persistent work-groups stall across PCIe. |
